"""
CLI commands for workspace-qdrant-mcp.

This package provides command-line interfaces for managing memory rules,
administering the system, and other workspace operations.
"""
