"""Web interface for memory curation."""

from .server import create_web_app

__all__ = ["create_web_app"]
