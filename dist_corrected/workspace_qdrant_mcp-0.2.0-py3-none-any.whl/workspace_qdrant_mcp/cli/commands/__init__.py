from ...observability import get_logger

logger = get_logger(__name__)
"""Unified CLI command modules.

This package contains the individual command implementations for each
domain of the wqm CLI interface.
"""
